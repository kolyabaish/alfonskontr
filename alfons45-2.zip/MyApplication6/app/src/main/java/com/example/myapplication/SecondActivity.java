package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.app.Activity;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            TextView ageView = findViewById(R.id.ageView);
            String age = extras.getString(MainActivity.AGE_KEY);
            ageView.setText("Возраст: " + age);

            Button back = findViewById(R.id.back);
            Button next = findViewById(R.id.next);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent dalh = new Intent(SecondActivity.this, ThreeActivity.class);
                    SecondActivity.this.startActivity(dalh);
                }
            });

            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent switcher = new Intent(SecondActivity.this, MainActivity.class);
                    SecondActivity.this.startActivity(switcher);
                }

                public void onCancelClick(View v) {
                    setResult(RESULT_CANCELED);
                    finish();
                }

                public void onButton1Click(View v) {
                    sendMessage("Доступ разрешен");
                }

                public void onButton2Click(View v) {
                    sendMessage("Доступ запрещен");
                }

                public void onButton3Click(View v) {
                    sendMessage("Недопустимый возраст");
                }

                private void sendMessage(String message) {

                    Intent data = new Intent();
                    data.putExtra(MainActivity.ACCESS_MESSAGE, message);
                    setResult(RESULT_OK, data);
                    finish();
                }
            });
        }

    }
    public void onClick(View v) {

        EditText nameText = findViewById(R.id.name);
        EditText companyText = findViewById(R.id.company);
        EditText ageText = findViewById(R.id.age);

        String name = nameText.getText().toString();
        String company = companyText.getText().toString();
        int age = Integer.parseInt(ageText.getText().toString());

        Intent intent = new Intent(this, ThreeActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("company", company);
        intent.putExtra("age", age);
        startActivity(intent);
    }
}


